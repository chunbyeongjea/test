package ch06;

public class AnonTest {

	public static void main(String[] args) {
		
		new AnonClass();
	}

}

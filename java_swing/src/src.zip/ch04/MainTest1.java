package ch04;

public class MainTest1 {

	public static void main(String[] args) {
		
		new MyEventListener1();
		
	}

}
